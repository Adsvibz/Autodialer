package com.autodialer.pro

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.ContactsContract.CommonDataKinds.Phone
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun Context.has(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

fun cleanNumber(raw: String): String = buildString {
    for (c in raw) {
        if (c.isDigit()) append(Character.digit(c, 10))
        else if (c == '+' || c == '*' || c == '#') append(c)
    }
}

fun dialable(n: String, cc: String): String {
    val c = cc.filter { it.isDigit() }
    return if (c.isNotEmpty() && n.startsWith("0")) "+$c${n.drop(1)}" else n
}

private val numRegex = Regex("\\+?[0-9٠-٩][0-9٠-٩ \\-()]{5,}")

fun parseLines(text: String): List<Pair<String, String>> = text.lines().mapNotNull { line ->
    var num: String? = null
    val names = mutableListOf<String>()
    for (raw in line.split(',', ';', '\t', '|')) {
        val p = raw.trim()
        if (p.isEmpty()) continue
        val digits = cleanNumber(p)
        val numeric = p.all { it.isDigit() || it in "+-() *#." }
        if (num == null && numeric && digits.length >= 5) num = digits else names.add(p)
    }
    if (num == null) {
        val m = numRegex.find(line)
        if (m != null) {
            num = cleanNumber(m.value)
            names.clear()
            val rest = line.replace(m.value, " ").trim().trim(',', ';', '-', ' ')
            if (rest.isNotEmpty()) names.add(rest)
        }
    }
    num?.let { names.joinToString(" ") to it }
}

fun fmtTime(ms: Long): String = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(ms))
fun fmtDur(s: Int): String = "%d:%02d".format(s / 60, s % 60)

fun shareText(ctx: Context, text: String) {
    val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
    ctx.startActivity(Intent.createChooser(i, "مشاركة التقرير"))
}

fun loadContacts(ctx: Context): List<Pair<String, String>> {
    val out = ArrayList<Pair<String, String>>()
    val seen = HashSet<String>()
    runCatching {
        ctx.contentResolver.query(
            Phone.CONTENT_URI, arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER), null, null, "${Phone.DISPLAY_NAME} ASC"
        )?.use { c ->
            while (c.moveToNext()) {
                val n = cleanNumber(c.getString(1) ?: "")
                if (n.length >= 3 && seen.add(n)) out.add((c.getString(0) ?: "") to n)
            }
        }
    }
    return out
}
