package com.autodialer.pro

import android.Manifest
import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

class MainActivity : ComponentActivity() {

    private var afterPerms: (() -> Unit)? = null
    private var afterContacts: (() -> Unit)? = null

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (has(Manifest.permission.CALL_PHONE) && has(Manifest.permission.READ_PHONE_STATE)) afterPerms?.invoke()
            else Toast.makeText(this, "صلاحيات الاتصال وحالة الهاتف مطلوبة لتشغيل الحملة", Toast.LENGTH_LONG).show()
            afterPerms = null
        }

    private val contactsLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) afterContacts?.invoke()
            afterContacts = null
        }

    fun ensureContacts(after: () -> Unit) {
        if (has(Manifest.permission.READ_CONTACTS)) after()
        else { afterContacts = after; contactsLauncher.launch(Manifest.permission.READ_CONTACTS) }
    }

    fun startCampaign(listId: String) {
        val st = Store.camp.status
        if (st == CS.RUNNING || st == CS.PAUSED || st == CS.WAITING) {
            Toast.makeText(this, "توجد حملة جارية بالفعل", Toast.LENGTH_SHORT).show()
            Store.tab = 1
            return
        }
        val need = mutableListOf(
            Manifest.permission.CALL_PHONE, Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_CALL_LOG, Manifest.permission.ANSWER_PHONE_CALLS
        )
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = need.filter { !has(it) }
        val go = {
            Store.runListId = listId
            Store.tab = 1
            DialerService.send(this, DialerService.ACT_START, listId)
        }
        if (missing.isEmpty()) go() else { afterPerms = go; permLauncher.launch(missing.toTypedArray()) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                AppTheme { Root(this@MainActivity) }
            }
        }
    }
}

@Composable
fun Root(act: MainActivity) {
    val keep = Store.cfg.keepScreenOn && (Store.camp.status == CS.RUNNING || Store.camp.status == CS.WAITING)
    val ctx = LocalContext.current as Activity
    LaunchedEffect(keep) {
        if (keep) ctx.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else ctx.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }
    Scaffold(
        bottomBar = {
            NavigationBar {
                val items = listOf(
                    "القوائم" to Icons.Default.Menu, "الحملة" to Icons.Default.Call,
                    "السجل" to Icons.Default.DateRange, "الإعدادات" to Icons.Default.Settings
                )
                items.forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(
                        selected = Store.tab == i, onClick = { Store.tab = i },
                        icon = { Icon(icon, null) }, label = { Text(label) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            val sel = Store.selectedListId
            when (Store.tab) {
                0 -> if (sel == null) ListsScreen() else ListDetail(sel, act)
                1 -> CampaignScreen(act)
                2 -> LogScreen()
                else -> SettingsScreen()
            }
        }
    }
}
