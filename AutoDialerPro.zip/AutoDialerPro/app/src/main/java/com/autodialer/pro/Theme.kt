package com.autodialer.pro

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

private val LightC = lightColorScheme(
    primary = Color(0xFF4F46E5), onPrimary = Color.White,
    primaryContainer = Color(0xFFE0E7FF), onPrimaryContainer = Color(0xFF1E1B4B),
    secondary = Color(0xFF0D9488), background = Color(0xFFF6F7FB), surface = Color.White,
    surfaceVariant = Color(0xFFEDEFF7), onSurfaceVariant = Color(0xFF5B6074), outline = Color(0xFFCBD0E0)
)
private val DarkC = darkColorScheme(
    primary = Color(0xFFA5B4FC), onPrimary = Color(0xFF1E1B4B),
    primaryContainer = Color(0xFF3730A3), onPrimaryContainer = Color(0xFFE0E7FF),
    secondary = Color(0xFF5EEAD4), background = Color(0xFF0F1115), surface = Color(0xFF171A21),
    surfaceVariant = Color(0xFF232733), onSurface = Color(0xFFE6E8EF), onBackground = Color(0xFFE6E8EF),
    onSurfaceVariant = Color(0xFFA3A9BC), outline = Color(0xFF3A4054)
)

fun statusColor(s: Int): Color = when (s) {
    St.ANSWERED -> Color(0xFF16A34A)
    St.NO_ANSWER -> Color(0xFFF59E0B)
    St.FAILED -> Color(0xFFDC2626)
    St.CALLING -> Color(0xFF2563EB)
    St.DONE -> Color(0xFF0D9488)
    else -> Color(0xFF8A90A5)
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val c = Store.cfg
    val dark = when (c.themeMode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    val ctx = LocalContext.current
    val scheme = if (c.dynamicColor && Build.VERSION.SDK_INT >= 31) {
        if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
    } else if (dark) DarkC else LightC
    MaterialTheme(
        colorScheme = scheme,
        shapes = Shapes(medium = RoundedCornerShape(16.dp), large = RoundedCornerShape(22.dp))
    ) {
        Surface(color = MaterialTheme.colorScheme.background, content = content)
    }
}
