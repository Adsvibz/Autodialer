@file:OptIn(ExperimentalMaterial3Api::class)

package com.autodialer.pro

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

// ======================= shared bits =======================
@Composable
fun NumText(n: String, modifier: Modifier = Modifier, style: TextStyle = MaterialTheme.typography.bodyMedium,
            color: Color = Color.Unspecified) {
    Text(n, modifier = modifier, style = style.copy(textDirection = TextDirection.Ltr), color = color)
}

@Composable
fun StatusChip(s: Int) {
    val c = statusColor(s)
    Surface(color = c.copy(alpha = 0.15f), shape = RoundedCornerShape(50)) {
        Text(St.label(s), color = c, style = MaterialTheme.typography.labelMedium,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp))
    }
}

@Composable
fun MenuItem(text: String, onClick: () -> Unit) = DropdownMenuItem(text = { Text(text) }, onClick = onClick)

@Composable
fun NameDialog(title: String, initial: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var t by remember { mutableStateOf(initial) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(title) },
        text = { OutlinedTextField(t, { t = it }, singleLine = true, label = { Text("الاسم") }) },
        confirmButton = { TextButton(onClick = { if (t.isNotBlank()) onOk(t.trim()) }) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } })
}

@Composable
fun EntryDialog(initial: Entry?, onDismiss: () -> Unit, onSave: (String, String) -> Unit) {
    var n by remember { mutableStateOf(initial?.name ?: "") }
    var p by remember { mutableStateOf(initial?.number ?: "") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (initial == null) "إضافة رقم" else "تعديل") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(n, { n = it }, singleLine = true, label = { Text("الاسم (اختياري)") })
                OutlinedTextField(p, { p = it }, singleLine = true, label = { Text("رقم الموبايل") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
            }
        },
        confirmButton = { TextButton(onClick = { if (cleanNumber(p).length >= 3) onSave(n, p) }) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } })
}

@Composable
fun BulkDialog(onDismiss: () -> Unit, onAdd: (String) -> Unit) {
    var t by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("لصق أرقام") },
        text = {
            OutlinedTextField(t, { t = it }, minLines = 6, maxLines = 10, modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("رقم في كل سطر\nأو: الاسم,الرقم") })
        },
        confirmButton = { TextButton(onClick = { onAdd(t) }) { Text("إضافة") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } })
}

@Composable
fun ConfirmDialog(text: String, onDismiss: () -> Unit, onOk: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, text = { Text(text) },
        confirmButton = { TextButton(onClick = onOk) { Text("تأكيد") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } })
}

@Composable
fun ContactsDialog(onDismiss: () -> Unit, onAdd: (List<Pair<String, String>>) -> Unit) {
    val ctx = LocalContext.current
    val all = remember { loadContacts(ctx) }
    var q by remember { mutableStateOf("") }
    val sel = remember { mutableStateListOf<String>() }
    val shown = all.filter { q.isBlank() || it.first.contains(q, true) || it.second.contains(q) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("جهات الاتصال (${sel.size})") },
        text = {
            Column {
                OutlinedTextField(q, { q = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("بحث") })
                Row {
                    TextButton(onClick = { sel.clear(); sel.addAll(shown.map { it.second }) }) { Text("تحديد الكل") }
                    TextButton(onClick = { sel.clear() }) { Text("مسح") }
                }
                LazyColumn(Modifier.height(300.dp)) {
                    items(shown, key = { it.second }) { (n, num) ->
                        Row(Modifier.fillMaxWidth().clickable { if (num in sel) sel.remove(num) else sel.add(num) },
                            verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = num in sel, onCheckedChange = null)
                            Spacer(Modifier.width(8.dp))
                            Column {
                                Text(n.ifBlank { num })
                                NumText(num, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onAdd(all.filter { it.second in sel }) }) { Text("إضافة") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } })
}

// ======================= lists =======================
@Composable
fun ListsScreen() {
    var showNew by remember { mutableStateOf(false) }
    Scaffold(
        topBar = { CenterAlignedTopAppBar(title = { Text("قوائم الاتصال", fontWeight = FontWeight.Bold) }) },
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = { showNew = true },
                icon = { Icon(Icons.Default.Add, null) }, text = { Text("قائمة جديدة") })
        }
    ) { pad ->
        if (Store.lists.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(pad), Alignment.Center) {
                Text("لا توجد قوائم بعد.\nأنشئ قائمة وأضف أرقامك.", textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(Store.lists, key = { it.id }) { l ->
                    val total = l.entries.size
                    val ok = l.entries.count { it.status == St.ANSWERED || it.status == St.DONE }
                    Card(onClick = { Store.selectedListId = l.id }, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text(l.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text("$total رقم • $ok تم الرد", style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                            if (total > 0) LinearProgressIndicator(progress = { ok / total.toFloat() },
                                modifier = Modifier.fillMaxWidth().padding(top = 10.dp))
                        }
                    }
                }
                item { Spacer(Modifier.height(80.dp)) }
            }
        }
    }
    if (showNew) NameDialog("قائمة جديدة", "", { showNew = false }) { n ->
        Store.selectedListId = Store.addList(n); showNew = false
    }
}

@Composable
fun ListDetail(listId: String, act: MainActivity) {
    val list = Store.lists.find { it.id == listId }
    if (list == null) { LaunchedEffect(Unit) { Store.selectedListId = null }; return }
    val ctx = LocalContext.current
    BackHandler { Store.selectedListId = null }
    var query by remember { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    var dlg by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<Entry?>(null) }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val text = runCatching {
                ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            }.getOrNull() ?: ""
            val n = Store.addEntries(listId, parseLines(text))
            Toast.makeText(ctx, "تمت إضافة $n رقم", Toast.LENGTH_SHORT).show()
        }
    }
    val shown = list.entries.filter { query.isBlank() || it.name.contains(query, true) || it.number.contains(query) }
    val ok = list.entries.count { it.status == St.ANSWERED || it.status == St.DONE }
    val na = list.entries.count { it.status == St.NO_ANSWER }
    val fl = list.entries.count { it.status == St.FAILED }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(list.name, fontWeight = FontWeight.Bold, maxLines = 1) },
                navigationIcon = {
                    IconButton(onClick = { Store.selectedListId = null }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, null)
                    }
                },
                actions = {
                    Box {
                        IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, null) }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            MenuItem("إعادة تسمية القائمة") { menu = false; dlg = "rename" }
                            MenuItem("إعادة تعيين الحالات") { menu = false; Store.resetStatuses(listId) }
                            MenuItem("حذف الأرقام المكررة") {
                                menu = false
                                Toast.makeText(ctx, "تم حذف ${Store.dedupe(listId)} رقم مكرر", Toast.LENGTH_SHORT).show()
                            }
                            MenuItem("حذف من تم الرد عليهم") { menu = false; Store.removeAnswered(listId) }
                            MenuItem("مشاركة تقرير القائمة") { menu = false; shareText(ctx, Store.listReport(list)) }
                            MenuItem("مسح كل الأرقام") { menu = false; dlg = "clear" }
                            MenuItem("حذف القائمة") { menu = false; dlg = "delete" }
                        }
                    }
                }
            )
        },
        floatingActionButton = {
            if (list.entries.isNotEmpty()) ExtendedFloatingActionButton(
                onClick = { act.startCampaign(listId) },
                icon = { Icon(Icons.Default.PlayArrow, null) }, text = { Text("ابدأ الحملة") })
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AssistChip(onClick = { dlg = "add" }, label = { Text("رقم") },
                    leadingIcon = { Icon(Icons.Default.Add, null, Modifier.size(18.dp)) })
                AssistChip(onClick = { dlg = "bulk" }, label = { Text("لصق أرقام") })
                AssistChip(onClick = { importer.launch(arrayOf("*/*")) }, label = { Text("ملف CSV / TXT") })
                AssistChip(onClick = { act.ensureContacts { dlg = "contacts" } }, label = { Text("من جهات الاتصال") },
                    leadingIcon = { Icon(Icons.Default.Person, null, Modifier.size(18.dp)) })
            }
            OutlinedTextField(query, { query = it }, singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                placeholder = { Text("بحث بالاسم أو الرقم") },
                leadingIcon = { Icon(Icons.Default.Search, null) })
            Text("${list.entries.size} رقم • تم الرد $ok • لم يُرد $na • فشل $fl",
                style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
            LazyColumn(Modifier.weight(1f)) {
                items(shown, key = { it.id }) { e ->
                    Row(Modifier.fillMaxWidth().clickable { editing = e }.padding(start = 16.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            if (e.name.isNotBlank()) {
                                Text(e.name, fontWeight = FontWeight.Medium)
                                NumText(e.number, style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            } else NumText(e.number, style = MaterialTheme.typography.bodyLarge)
                        }
                        StatusChip(e.status)
                        IconButton(onClick = { Store.deleteEntry(listId, e.id) }) {
                            Icon(Icons.Default.Delete, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                }
                item { Spacer(Modifier.height(90.dp)) }
            }
        }
    }

    when (dlg) {
        "add" -> EntryDialog(null, { dlg = "" }) { n, num -> Store.addEntries(listId, listOf(n to num)); dlg = "" }
        "bulk" -> BulkDialog({ dlg = "" }) { t ->
            val n = Store.addEntries(listId, parseLines(t))
            Toast.makeText(ctx, "تمت إضافة $n رقم", Toast.LENGTH_SHORT).show(); dlg = ""
        }
        "contacts" -> ContactsDialog({ dlg = "" }) { sel ->
            val n = Store.addEntries(listId, sel)
            Toast.makeText(ctx, "تمت إضافة $n رقم", Toast.LENGTH_SHORT).show(); dlg = ""
        }
        "rename" -> NameDialog("إعادة تسمية", list.name, { dlg = "" }) { n ->
            Store.updateList(listId) { it.copy(name = n) }; dlg = ""
        }
        "clear" -> ConfirmDialog("حذف كل الأرقام من القائمة؟", { dlg = "" }) {
            Store.updateList(listId) { it.copy(entries = emptyList()) }; dlg = ""
        }
        "delete" -> ConfirmDialog("حذف القائمة بكل أرقامها؟", { dlg = "" }) {
            dlg = ""; Store.deleteList(listId); Store.selectedListId = null
        }
    }
    editing?.let { e ->
        EntryDialog(e, { editing = null }) { n, num ->
            Store.updateEntry(listId, e.id) { it.copy(name = n.trim(), number = cleanNumber(num)) }; editing = null
        }
    }
}

// ======================= campaign =======================
@Composable
fun CampaignScreen(act: MainActivity) {
    val c = Store.camp
    val ctx = LocalContext.current
    val active = c.status == CS.RUNNING || c.status == CS.PAUSED || c.status == CS.WAITING
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(active) { while (active) { now = System.currentTimeMillis(); delay(500) } }

    Scaffold(topBar = { CenterAlignedTopAppBar(title = { Text("الحملة", fontWeight = FontWeight.Bold) }) }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)) {

            if (active || c.status == CS.FINISHED) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(20.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(c.listName, style = MaterialTheme.typography.labelLarge)
                        val title = when (c.status) {
                            CS.PAUSED -> "⏸ متوقفة مؤقتًا"
                            CS.WAITING -> "⏳ بانتظار ساعات السماح"
                            CS.FINISHED -> "✅ ${c.message}"
                            else -> if (c.currentNumber.isNotEmpty()) "📞 جارٍ الاتصال" else "⏱ استعداد"
                        }
                        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center)
                        if (c.status == CS.RUNNING && c.currentNumber.isNotEmpty()) {
                            if (c.currentName.isNotEmpty()) Text(c.currentName, style = MaterialTheme.typography.titleMedium)
                            NumText(c.currentNumber, style = MaterialTheme.typography.titleLarge)
                        } else if (c.status == CS.RUNNING && c.nextAt > now) {
                            Text("${c.message} ${(c.nextAt - now + 999) / 1000} ث")
                        } else if (c.status == CS.WAITING) Text(c.message, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(6.dp))
                        LinearProgressIndicator(progress = { if (c.total == 0) 0f else c.done / c.total.toFloat() },
                            modifier = Modifier.fillMaxWidth())
                        Text("${c.done} / ${c.total}" + if (c.loops > 1) "  •  الجولة ${c.loop}/${c.loops}" else "")
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    Stat("تم الرد", c.answered, statusColor(St.ANSWERED), Modifier.weight(1f))
                    Stat("لم يُرد", c.noAnswer, statusColor(St.NO_ANSWER), Modifier.weight(1f))
                    Stat("فشل", c.failed, statusColor(St.FAILED), Modifier.weight(1f))
                }
            }

            if (active) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    if (c.status == CS.PAUSED)
                        Button(onClick = { DialerService.send(ctx, DialerService.ACT_RESUME) }, modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 6.dp)) { Text("استئناف") }
                    else
                        FilledTonalButton(onClick = { DialerService.send(ctx, DialerService.ACT_PAUSE) }, modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 6.dp)) { Text("إيقاف مؤقت") }
                    OutlinedButton(onClick = { DialerService.send(ctx, DialerService.ACT_SKIP) }, modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(horizontal = 6.dp)) { Text("إنهاء الحالية") }
                    Button(onClick = { DialerService.send(ctx, DialerService.ACT_STOP) }, modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        contentPadding = PaddingValues(horizontal = 6.dp)) { Text("إيقاف") }
                }
            } else {
                val sel = Store.runListId?.takeIf { id -> Store.lists.any { it.id == id } } ?: Store.lists.firstOrNull()?.id
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("اختر القائمة", fontWeight = FontWeight.Bold)
                        if (Store.lists.isEmpty()) Text("أنشئ قائمة أولاً من تبويب القوائم.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Store.lists.forEach { l ->
                            Row(Modifier.fillMaxWidth().clickable { Store.runListId = l.id },
                                verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(selected = l.id == sel, onClick = { Store.runListId = l.id })
                                Text("${l.name}  (${l.entries.size})")
                            }
                        }
                    }
                }
                Button(onClick = { sel?.let { act.startCampaign(it) } }, enabled = sel != null,
                    modifier = Modifier.fillMaxWidth().height(54.dp)) {
                    Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(8.dp)); Text("ابدأ الحملة")
                }
                val s = Store.cfg
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("الإعدادات الحالية", fontWeight = FontWeight.Bold)
                        val gap = if (s.randomDelay) "${s.delaySec}–${s.delayMaxSec} ث (عشوائي)" else "${s.delaySec} ث"
                        Text("• الانتظار بين المكالمات: $gap")
                        Text("• إعادة المحاولة: ${s.retries} • الجولات: ${s.loops}")
                        Text("• SIM: ${if (s.simIndex < 0) "الافتراضي" else "SIM ${s.simIndex + 1}"}" +
                            if (s.maxCallSec > 0) " • حد المكالمة ${s.maxCallSec} ث" else "")
                        Text("عدّلها من تبويب الإعدادات", style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
fun Stat(label: String, v: Int, color: Color, modifier: Modifier) {
    Card(modifier) {
        Column(Modifier.padding(12.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("$v", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = color)
            Text(label, style = MaterialTheme.typography.labelMedium)
        }
    }
}

// ======================= log =======================
@Composable
fun LogScreen() {
    val ctx = LocalContext.current
    var f by remember { mutableIntStateOf(-1) }
    var confirm by remember { mutableStateOf(false) }
    val shown = Store.log.filter { f == -1 || it.status == f }
    Scaffold(topBar = {
        CenterAlignedTopAppBar(title = { Text("السجل", fontWeight = FontWeight.Bold) }, actions = {
            IconButton(onClick = { if (shown.isNotEmpty()) shareText(ctx, Store.logReport(shown)) }) { Icon(Icons.Default.Share, null) }
            IconButton(onClick = { confirm = true }) { Icon(Icons.Default.Delete, null) }
        })
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(-1 to "الكل", St.ANSWERED to "تم الرد", St.NO_ANSWER to "لم يُرد", St.FAILED to "فشل", St.DONE to "انتهت")
                    .forEach { (k, n) -> FilterChip(selected = f == k, onClick = { f = k }, label = { Text(n) }) }
            }
            if (shown.isEmpty()) Box(Modifier.fillMaxSize(), Alignment.Center) {
                Text("لا يوجد سجل بعد", color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else LazyColumn {
                items(shown) { l ->
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            if (l.name.isNotBlank()) Text(l.name, fontWeight = FontWeight.Medium)
                            NumText(l.number)
                            Text(fmtTime(l.time) + " • " + l.listName + (if (l.duration > 0) " • ${fmtDur(l.duration)}" else "") +
                                " • محاولة ${l.attempt}", style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        StatusChip(l.status)
                    }
                    Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                }
            }
        }
    }
    if (confirm) ConfirmDialog("مسح كل السجل؟", { confirm = false }) { Store.clearLog(); confirm = false }
}

// ======================= settings =======================
@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary)
            content()
        }
    }
}

@Composable
fun SliderRow(title: String, value: Int, min: Int, max: Int, suffix: String, zeroText: String? = null,
              onChange: (Int) -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title)
            Text(if (value == 0 && zeroText != null) zeroText else "$value $suffix",
                color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        }
        Slider(value = value.toFloat(), onValueChange = { onChange(it.roundToInt()) },
            valueRange = min.toFloat()..max.toFloat())
    }
}

@Composable
fun SwitchRow(title: String, sub: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title)
            if (sub != null) Text(sub, style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun ChipsRow(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEachIndexed { i, o -> FilterChip(selected = selected == i, onClick = { onSelect(i) }, label = { Text(o) }) }
    }
}

@Composable
fun SettingsScreen() {
    val c = Store.cfg
    val ctx = LocalContext.current
    fun up(f: (Cfg) -> Cfg) = Store.updateCfg(f)

    Scaffold(topBar = { CenterAlignedTopAppBar(title = { Text("الإعدادات", fontWeight = FontWeight.Bold) }) }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)) {

            Section("التوقيت") {
                SliderRow("الانتظار بين المكالمات", c.delaySec, 0, 120, "ث") { v -> up { it.copy(delaySec = v) } }
                SwitchRow("انتظار عشوائي", "مدة عشوائية بين الحدّين لتبدو طبيعية", c.randomDelay) { v -> up { it.copy(randomDelay = v) } }
                if (c.randomDelay) SliderRow("أقصى مدة انتظار", c.delayMaxSec, 1, 300, "ث") { v -> up { it.copy(delayMaxSec = v) } }
                SliderRow("عدّاد قبل بدء الحملة", c.startCountdown, 0, 30, "ث", "فوري") { v -> up { it.copy(startCountdown = v) } }
                SliderRow("إنهاء المكالمة تلقائيًا بعد", c.maxCallSec, 0, 600, "ث", "معطّل") { v -> up { it.copy(maxCallSec = v) } }
                Text("مفيد لقطع الرنين الطويل أو تحديد مدة قصوى لكل مكالمة.", style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            Section("الحملة") {
                SliderRow("إعادة المحاولة لمن لم يرد", c.retries, 0, 5, "مرات", "بدون") { v -> up { it.copy(retries = v) } }
                SliderRow("عدد الجولات (تكرار القائمة)", c.loops, 1, 20, "") { v -> up { it.copy(loops = v) } }
                SwitchRow("ترتيب عشوائي", "خلط ترتيب الأرقام عند البدء", c.shuffle) { v -> up { it.copy(shuffle = v) } }
                SwitchRow("تخطّي من تم الرد عليهم", "لا يتصل بأرقام ردّت سابقًا", c.skipAnswered) { v -> up { it.copy(skipAnswered = v) } }
                SwitchRow("اكتشاف الرد من سجل المكالمات", "أدق طريقة لمعرفة (رد / لم يرد)", c.useCallLog) { v -> up { it.copy(useCallLog = v) } }
            }

            Section("الاتصال") {
                Text("الشريحة المستخدمة")
                ChipsRow(listOf("الافتراضي", "SIM 1", "SIM 2"), c.simIndex + 1) { i -> up { it.copy(simIndex = i - 1) } }
                OutlinedTextField(c.countryCode, { t -> up { s -> s.copy(countryCode = t.filter { ch -> ch.isDigit() }) } },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                    label = { Text("كود الدولة (اختياري، مثال 20)") },
                    supportingText = { Text("لو كتبته، الرقم 010… يتحول إلى +2010…") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            }

            Section("ساعات السماح بالاتصال") {
                SwitchRow("تحديد وقت للعمل", "الحملة تنتظر خارج هذه الساعات", c.quietEnabled) { v -> up { it.copy(quietEnabled = v) } }
                if (c.quietEnabled) {
                    SliderRow("من الساعة", c.quietFrom, 0, 23, ":00") { v -> up { it.copy(quietFrom = v) } }
                    SliderRow("إلى الساعة", c.quietTo, 0, 23, ":00") { v -> up { it.copy(quietTo = v) } }
                }
            }

            Section("المظهر والتنبيهات") {
                Text("السمة")
                ChipsRow(listOf("تلقائي", "فاتح", "داكن"), c.themeMode) { i -> up { it.copy(themeMode = i) } }
                SwitchRow("ألوان النظام (Material You)", "أندرويد 12 فما فوق", c.dynamicColor) { v -> up { it.copy(dynamicColor = v) } }
                SwitchRow("إبقاء الشاشة مفتوحة أثناء الحملة", null, c.keepScreenOn) { v -> up { it.copy(keepScreenOn = v) } }
                SwitchRow("اهتزاز عند انتهاء الحملة", null, c.vibrateOnFinish) { v -> up { it.copy(vibrateOnFinish = v) } }
            }

            Section("الصلاحيات والتشغيل في الخلفية") {
                listOf(
                    "الاتصال" to Manifest.permission.CALL_PHONE,
                    "حالة الهاتف" to Manifest.permission.READ_PHONE_STATE,
                    "سجل المكالمات" to Manifest.permission.READ_CALL_LOG,
                    "إنهاء المكالمات" to Manifest.permission.ANSWER_PHONE_CALLS,
                    "جهات الاتصال" to Manifest.permission.READ_CONTACTS
                ).forEach { (n, p) ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(n); Text(if (ctx.has(p)) "✅ ممنوحة" else "❌ غير ممنوحة")
                    }
                }
                OutlinedButton(onClick = {
                    ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", ctx.packageName, null)))
                }, modifier = Modifier.fillMaxWidth()) { Text("فتح إعدادات التطبيق") }
                OutlinedButton(onClick = {
                    ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                }, modifier = Modifier.fillMaxWidth()) { Text("استثناء من توفير البطارية") }
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}
