package com.autodialer.pro

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

object St {
    const val PENDING = 0
    const val CALLING = 1
    const val ANSWERED = 2
    const val NO_ANSWER = 3
    const val FAILED = 4
    const val DONE = 5
    fun label(s: Int) = when (s) {
        PENDING -> "في الانتظار"
        CALLING -> "جارٍ الاتصال"
        ANSWERED -> "تم الرد"
        NO_ANSWER -> "لم يُرد"
        FAILED -> "فشل"
        else -> "انتهت"
    }
}

object CS {
    const val IDLE = 0
    const val RUNNING = 1
    const val PAUSED = 2
    const val WAITING = 3
    const val FINISHED = 4
}

data class Entry(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "",
    val number: String,
    val status: Int = St.PENDING,
    val attempts: Int = 0,
    val duration: Int = 0
)

data class CallList(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val entries: List<Entry> = emptyList()
)

data class LogItem(
    val time: Long, val listName: String, val name: String, val number: String,
    val status: Int, val duration: Int, val attempt: Int
)

data class CampState(
    val status: Int = CS.IDLE,
    val listName: String = "",
    val total: Int = 0,
    val done: Int = 0,
    val answered: Int = 0,
    val noAnswer: Int = 0,
    val failed: Int = 0,
    val currentName: String = "",
    val currentNumber: String = "",
    val message: String = "",
    val loop: Int = 1,
    val loops: Int = 1,
    val nextAt: Long = 0
)

data class Cfg(
    val delaySec: Int = 5,
    val randomDelay: Boolean = false,
    val delayMaxSec: Int = 15,
    val startCountdown: Int = 3,
    val maxCallSec: Int = 0,
    val retries: Int = 0,
    val loops: Int = 1,
    val shuffle: Boolean = false,
    val skipAnswered: Boolean = true,
    val useCallLog: Boolean = true,
    val countryCode: String = "",
    val simIndex: Int = -1,
    val quietEnabled: Boolean = false,
    val quietFrom: Int = 9,
    val quietTo: Int = 21,
    val keepScreenOn: Boolean = true,
    val vibrateOnFinish: Boolean = true,
    val themeMode: Int = 0,
    val dynamicColor: Boolean = false
) {
    fun toJson(): JSONObject = JSONObject()
        .put("delaySec", delaySec).put("randomDelay", randomDelay).put("delayMaxSec", delayMaxSec)
        .put("startCountdown", startCountdown).put("maxCallSec", maxCallSec).put("retries", retries)
        .put("loops", loops).put("shuffle", shuffle).put("skipAnswered", skipAnswered)
        .put("useCallLog", useCallLog).put("countryCode", countryCode).put("simIndex", simIndex)
        .put("quietEnabled", quietEnabled).put("quietFrom", quietFrom).put("quietTo", quietTo)
        .put("keepScreenOn", keepScreenOn).put("vibrateOnFinish", vibrateOnFinish)
        .put("themeMode", themeMode).put("dynamicColor", dynamicColor)

    companion object {
        fun fromJson(o: JSONObject): Cfg {
            val d = Cfg()
            return Cfg(
                delaySec = o.optInt("delaySec", d.delaySec),
                randomDelay = o.optBoolean("randomDelay", d.randomDelay),
                delayMaxSec = o.optInt("delayMaxSec", d.delayMaxSec),
                startCountdown = o.optInt("startCountdown", d.startCountdown),
                maxCallSec = o.optInt("maxCallSec", d.maxCallSec),
                retries = o.optInt("retries", d.retries),
                loops = o.optInt("loops", d.loops),
                shuffle = o.optBoolean("shuffle", d.shuffle),
                skipAnswered = o.optBoolean("skipAnswered", d.skipAnswered),
                useCallLog = o.optBoolean("useCallLog", d.useCallLog),
                countryCode = o.optString("countryCode", d.countryCode),
                simIndex = o.optInt("simIndex", d.simIndex),
                quietEnabled = o.optBoolean("quietEnabled", d.quietEnabled),
                quietFrom = o.optInt("quietFrom", d.quietFrom),
                quietTo = o.optInt("quietTo", d.quietTo),
                keepScreenOn = o.optBoolean("keepScreenOn", d.keepScreenOn),
                vibrateOnFinish = o.optBoolean("vibrateOnFinish", d.vibrateOnFinish),
                themeMode = o.optInt("themeMode", d.themeMode),
                dynamicColor = o.optBoolean("dynamicColor", d.dynamicColor)
            )
        }
    }
}

object Store {
    private lateinit var sp: SharedPreferences

    val lists = mutableStateListOf<CallList>()
    val log = mutableStateListOf<LogItem>()
    var cfg by mutableStateOf(Cfg())
    var camp by mutableStateOf(CampState())
    var selectedListId by mutableStateOf<String?>(null)
    var runListId by mutableStateOf<String?>(null)
    var tab by mutableIntStateOf(0)

    fun init(ctx: Context) {
        if (::sp.isInitialized) return
        sp = ctx.applicationContext.getSharedPreferences("store", Context.MODE_PRIVATE)
        runCatching { sp.getString("cfg", null)?.let { cfg = Cfg.fromJson(JSONObject(it)) } }
        runCatching {
            sp.getString("lists", null)?.let { s ->
                val a = JSONArray(s)
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    val ea = o.getJSONArray("entries")
                    val es = (0 until ea.length()).map { k ->
                        val e = ea.getJSONObject(k)
                        val st = e.optInt("status")
                        Entry(e.getString("id"), e.optString("name"), e.getString("number"),
                            if (st == St.CALLING) St.PENDING else st, e.optInt("attempts"), e.optInt("duration"))
                    }
                    lists.add(CallList(o.getString("id"), o.getString("name"), es))
                }
            }
        }
        runCatching {
            sp.getString("log", null)?.let { s ->
                val a = JSONArray(s)
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    log.add(LogItem(o.getLong("t"), o.optString("l"), o.optString("n"), o.optString("p"),
                        o.optInt("s"), o.optInt("d"), o.optInt("a")))
                }
            }
        }
    }

    fun updateCfg(f: (Cfg) -> Cfg) {
        cfg = f(cfg)
        sp.edit().putString("cfg", cfg.toJson().toString()).apply()
    }

    private fun saveLists() {
        val a = JSONArray()
        lists.forEach { l ->
            val ea = JSONArray()
            l.entries.forEach { e ->
                ea.put(JSONObject().put("id", e.id).put("name", e.name).put("number", e.number)
                    .put("status", e.status).put("attempts", e.attempts).put("duration", e.duration))
            }
            a.put(JSONObject().put("id", l.id).put("name", l.name).put("entries", ea))
        }
        sp.edit().putString("lists", a.toString()).apply()
    }

    private fun saveLog() {
        val a = JSONArray()
        log.forEach {
            a.put(JSONObject().put("t", it.time).put("l", it.listName).put("n", it.name)
                .put("p", it.number).put("s", it.status).put("d", it.duration).put("a", it.attempt))
        }
        sp.edit().putString("log", a.toString()).apply()
    }

    fun addList(name: String): String {
        val l = CallList(name = name)
        lists.add(l); saveLists(); return l.id
    }

    fun deleteList(id: String) { lists.removeAll { it.id == id }; saveLists() }

    fun updateList(id: String, f: (CallList) -> CallList) {
        val i = lists.indexOfFirst { it.id == id }
        if (i >= 0) { lists[i] = f(lists[i]); saveLists() }
    }

    fun updateEntry(listId: String, entryId: String, f: (Entry) -> Entry) =
        updateList(listId) { l -> l.copy(entries = l.entries.map { if (it.id == entryId) f(it) else it }) }

    fun deleteEntry(listId: String, entryId: String) =
        updateList(listId) { l -> l.copy(entries = l.entries.filter { it.id != entryId }) }

    fun addEntries(listId: String, items: List<Pair<String, String>>): Int {
        var added = 0
        updateList(listId) { l ->
            val seen = l.entries.map { it.number }.toMutableSet()
            val fresh = items.mapNotNull { (n, num) ->
                val c = cleanNumber(num)
                if (c.length < 3 || !seen.add(c)) null else Entry(name = n.trim(), number = c)
            }
            added = fresh.size
            l.copy(entries = l.entries + fresh)
        }
        return added
    }

    fun dedupe(listId: String): Int {
        var removed = 0
        updateList(listId) { l ->
            val seen = HashSet<String>()
            val out = l.entries.filter { seen.add(it.number) }
            removed = l.entries.size - out.size
            l.copy(entries = out)
        }
        return removed
    }

    fun resetStatuses(listId: String) = updateList(listId) { l ->
        l.copy(entries = l.entries.map { it.copy(status = St.PENDING, attempts = 0, duration = 0) })
    }

    fun removeAnswered(listId: String) = updateList(listId) { l ->
        l.copy(entries = l.entries.filter { it.status != St.ANSWERED && it.status != St.DONE })
    }

    fun addLog(i: LogItem) {
        log.add(0, i)
        while (log.size > 1000) log.removeAt(log.lastIndex)
        saveLog()
    }

    fun clearLog() { log.clear(); saveLog() }

    fun listReport(l: CallList): String =
        "الاسم,الرقم,الحالة,المدة(ث),المحاولات\n" + l.entries.joinToString("\n") {
            "${it.name},${it.number},${St.label(it.status)},${it.duration},${it.attempts}"
        }

    fun logReport(items: List<LogItem>): String =
        "الوقت,القائمة,الاسم,الرقم,الحالة,المدة(ث),المحاولة\n" + items.joinToString("\n") {
            "${fmtTime(it.time)},${it.listName},${it.name},${it.number},${St.label(it.status)},${it.duration},${it.attempt}"
        }
}
